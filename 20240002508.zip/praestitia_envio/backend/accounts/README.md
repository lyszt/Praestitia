# Lista de Permissões (IDs) 

1 — ADMIN             : Acesso administrativo completo (todos os privilégios)
2  — MARKETING         : Ações de marketing (publicar, editar campanhas)
3  — VENDOR            : Ações de vendedor/fornecedor


