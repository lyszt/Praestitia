# praestitia/__init__.py
from . import db_optimization