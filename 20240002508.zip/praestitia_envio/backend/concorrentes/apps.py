from django.apps import AppConfig


class ConcorrentesConfig(AppConfig):
    name = 'concorrentes'
